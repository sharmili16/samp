#-----------MODULES IMPORT--------------------------------------
from tkinter import *
from tkinter import ttk
import pymsgbox
import mail
import random
import time
import datetime
import face_recognize
import serial
arduino = serial.Serial('COM29', 9600, timeout=3)
rfid = serial.Serial('COM6', 9600, timeout=3)

#---------------MAIN LOOP--------------------------
  
while 1:
    data=rfid.readline()
    print(data.decode())
    if(len(data.decode())>2):
        pymsgbox.alert(text="Shall I Start Face Recognition", title='Starting......!')
        voter= face_recognize.recognition()
        print(voter)
        if voter != "":
                    if ((voter =='palani') and ('A43B0DA' in data.decode())):
                        arduino.write(str.encode('a'))
                        pymsgbox.alert(timeout=1000,text="Thank You", title="Sucess!!")
                    else:
                        otp=random.randint(1000,9999)
                        print(otp)
                        mail.send_mail("pantech.demo19@gmail.com","novitech@2019","pantech.demo19@gmail.com",message="Your OTP :"+str(otp),path="img.jpg")
                        your_otp=pymsgbox.prompt(text="Enter your otp", title="OTP!")
                        
                        if (str(otp)==your_otp):
                            arduino.write(str.encode('a'))
                            pymsgbox.alert(timeout=5000,text="Thank You", title="Success!!")


                        else:
                           pymsgbox.alert(timeout=5000,text="Sorry... Invalid OTP. ", title=" ERROR..!!!")
                           arduino.write(str.encode('b'))
    else:
        print ("Read Your Card..")
                    
